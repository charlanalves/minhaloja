<?php

namespace app\models;

/**
 * This is the ActiveQuery class for [[\app\models\Loj06UsuarioCliente]].
 *
 * @see \app\models\Loj06UsuarioCliente
 */
class Loj06UsuarioClienteQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        $this->andWhere('[[status]]=1');
        return $this;
    }*/

    /**
     * @inheritdoc
     * @return \app\models\Loj06UsuarioCliente[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return \app\models\Loj06UsuarioCliente|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}