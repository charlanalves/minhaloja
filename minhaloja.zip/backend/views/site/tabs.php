<div id="myTabContent1" class="tab-content padding-10">
    
    <div class="tab-pane fade in active" id="s1">
           <?= $abaProdPendentes ?>
    </div>
    <div class="tab-pane fade" id="s2">
          <?= $abaProdAtivos ?>
    </div>
    <div class="tab-pane fade" id="s3">
            <?= $abaVendas ?>
    </div>

</div>