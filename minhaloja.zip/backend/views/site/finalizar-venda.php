<div id="container-finalizar-venda" class="form-actions fixed-page simple-hide">
    <div class="row">
        <div class="col-sm-2 finalizar-venda">
            <span>
                <a id="finalizarVenda" href="javascript:void(0);" class="btn btn-primary btn-lg">Finalizar Venda </a>
            </span>													
        </div>

<!--        <div class="col-sm-2">
                <ul class="pager wizard no-margin">

                        <li class="previous disabled">
                                <a href="javascript:void(0);" class="btn btn-lg btn-default">Anterior </a>
                        </li>
                        <li class="next">
                                <a href="javascript:void(0);" class="btn btn-lg txt-color-darken"> Próximo </a>
                        </li>
                </ul>
        </div>-->
    </div>
</div>

<script>
    


</script>