<br />
<br />
<br />
<?= common\components\widgets\pagamento\checkoutWidget::widget(['dados' => [1,2]]);
