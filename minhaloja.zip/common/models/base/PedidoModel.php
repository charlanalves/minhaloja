<?php

namespace common\models\base;

use Yii;
use yii\behaviors\TimestampBehavior;
use yii\behaviors\BlameableBehavior;
use mootensai\behaviors\UUIDBehavior;

/**
 * This is the base model class for table "loj11_pedido".
 *
 * @property integer $LOJ11_ID
 * @property integer $LOJ11_CLIENTE_ID
 * @property integer $LOJ11_USUARIO_ID
 * @property string $LOJ11_VALOR
 * @property string $LOJ11_VALOR_FRETE
 * @property string $LOJ11_FORMA_PGTO
 * @property integer $LOJ11_NUM_PARCELA
 * @property integer $LOJ11_STATUS
 * @property string $LOJ11_DT_INCLUSAO
 * @property string $LOJ11_CLIENTE_NOME
 * @property string $LOJ11_CLIENTE_EMAIL
 * @property string $LOJ11_ENTREGA_CEP
 * @property string $LOJ11_ENTREGA_ENDERECO
 * @property string $LOJ11_ENTREGA_NUM
 * @property string $LOJ11_ENTREGA_COMP
 * @property string $LOJ11_ENTREGA_BAIRRO
 * @property string $LOJ11_ENTREGA_CIDADE
 * @property string $LOJ11_ENTREGA_UF
 *
 * @property \common\models\Loj02Cliente $lOJ11CLIENTE
 * @property \common\models\Loj01Usuario $lOJ11USUARIO
 * @property \common\models\Loj12ProdutoPedido[] $loj12ProdutoPedidos
 * @property \common\models\Loj15StatusPedido[] $loj15StatusPedidos
 * @property \common\models\Loj14Status[] $lOJ15Statuses
 * @property \common\models\Loj16Pagamento[] $loj16Pagamentos
 */
class PedidoModel extends \yii\db\ActiveRecord
{
    use \mootensai\relation\RelationTrait;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['LOJ11_CLIENTE_ID', 'LOJ11_USUARIO_ID', 'LOJ11_VALOR'], 'required'],
            [['LOJ11_CLIENTE_ID', 'LOJ11_USUARIO_ID', 'LOJ11_NUM_PARCELA', 'LOJ11_STATUS'], 'integer'],
            [['LOJ11_VALOR', 'LOJ11_VALOR_FRETE'], 'number'],
            [['LOJ11_DT_INCLUSAO'], 'safe'],
            [['LOJ11_FORMA_PGTO'], 'string', 'max' => 1],
            [['LOJ11_CLIENTE_NOME', 'LOJ11_CLIENTE_EMAIL', 'LOJ11_ENTREGA_CEP', 'LOJ11_ENTREGA_ENDERECO', 'LOJ11_ENTREGA_NUM', 'LOJ11_ENTREGA_COMP', 'LOJ11_ENTREGA_BAIRRO', 'LOJ11_ENTREGA_CIDADE'], 'string', 'max' => 50],
            [['LOJ11_ENTREGA_UF'], 'string', 'max' => 2],       
        ];
    }
    
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'loj11_pedido';
    }

    /**
     * 
     * @return string
     * overwrite function optimisticLock
     * return string name of field are used to stored optimistic lock 
     * 
     */
    public function optimisticLock() {
        return 'lock';
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'LOJ11_ID' => 'Loj11  ID',
            'LOJ11_CLIENTE_ID' => 'Loj11  Cliente  ID',
            'LOJ11_USUARIO_ID' => 'Loj11  Usuario  ID',
            'LOJ11_VALOR' => 'Loj11  Valor',
            'LOJ11_VALOR_FRETE' => 'Loj11  Valor  Frete',
            'LOJ11_FORMA_PGTO' => 'Loj11  Forma  Pgto',
            'LOJ11_NUM_PARCELA' => 'Loj11  Num  Parcela',
            'LOJ11_STATUS' => 'Loj11  Status',
            'LOJ11_DT_INCLUSAO' => 'Loj11  Dt  Inclusao',
            'LOJ11_CLIENTE_NOME' => 'Loj11  Cliente  Nome',
            'LOJ11_CLIENTE_EMAIL' => 'Loj11  Cliente  Email',
            'LOJ11_ENTREGA_CEP' => 'Loj11  Entrega  Cep',
            'LOJ11_ENTREGA_ENDERECO' => 'Loj11  Entrega  Endereco',
            'LOJ11_ENTREGA_NUM' => 'Loj11  Entrega  Num',
            'LOJ11_ENTREGA_COMP' => 'Loj11  Entrega  Comp',
            'LOJ11_ENTREGA_BAIRRO' => 'Loj11  Entrega  Bairro',
            'LOJ11_ENTREGA_CIDADE' => 'Loj11  Entrega  Cidade',
            'LOJ11_ENTREGA_UF' => 'Loj11  Entrega  Uf',
        ];
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLOJ11CLIENTE()
    {
        return $this->hasOne(\common\models\Loj02Cliente::className(), ['LOJ02_ID' => 'LOJ11_CLIENTE_ID']);
    }
        
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLOJ11USUARIO()
    {
        return $this->hasOne(\common\models\Loj01Usuario::className(), ['LOJ01_ID' => 'LOJ11_USUARIO_ID']);
    }
        
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoj12ProdutoPedidos()
    {
        return $this->hasMany(\common\models\Loj12ProdutoPedido::className(), ['LOJ12_PEDIDO_ID' => 'LOJ11_ID']);
    }
        
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoj15StatusPedidos()
    {
        return $this->hasMany(\common\models\Loj15StatusPedido::className(), ['LOJ15_PEDIDO_ID' => 'LOJ11_ID']);
    }
        
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLOJ15Statuses()
    {
        return $this->hasMany(\common\models\Loj14Status::className(), ['LOJ14_ID' => 'LOJ15_STATUS_ID'])->viaTable('loj15_status_pedido', ['LOJ15_PEDIDO_ID' => 'LOJ11_ID']);
    }
        
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLoj16Pagamentos()
    {
        return $this->hasMany(\common\models\Loj16Pagamento::className(), ['LOJ16_PEDIDO_ID' => 'LOJ11_ID']);
    }
    
/**
     * @inheritdoc
     * @return array mixed
     */ 
    public function behaviors()
    {
        return [
            'timestamp' => [
                'class' => TimestampBehavior::className(),
                'createdAtAttribute' => 'created_at',
                'updatedAtAttribute' => 'updated_at',
                'value' => new \yii\db\Expression('NOW()'),
            ],
            'blameable' => [
                'class' => BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'uuid' => [
                'class' => UUIDBehavior::className(),
                'column' => 'id',
            ],
        ];
    }

    /**
     * @inheritdoc
     * @return \app\models\PedidoModelQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new \app\models\PedidoModelQuery(get_called_class());
    }
}
